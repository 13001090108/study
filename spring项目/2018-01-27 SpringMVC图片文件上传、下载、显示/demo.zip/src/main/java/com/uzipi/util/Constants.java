package com.uzipi.util;

public class Constants {
    public static final String IMG_PATH = "D:/upload/";
}
