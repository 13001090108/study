package spittr.config;

/**
 * Created by lsc on 2018/12/28.
 */
public class hello {
    public static void main(String[] args) {
        System.out.println("hello");
    }
}
